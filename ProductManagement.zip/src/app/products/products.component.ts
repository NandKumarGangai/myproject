import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Product} from '../product';
import { ProductService } from '../product.service';
import { NgForm } from '@angular/forms';
//import { $ } from 'jquery';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  @ViewChild('addBtn') addBtn : ElementRef
  @ViewChild('editBtn') editBtn : ElementRef

  products: Product[] = [];
  
  newProduct: Product = new Product();
  updateProduct: Product = new Product();
  p = 1;
  constructor(private productService: ProductService){}

  ngOnInit(){
    this.getProducts();
  }

  getProducts(){
    this.productService.getProducts().subscribe(product=> this.products = product);
  }

  addProduct(form:NgForm):void{
    console.log("In component: ", this.newProduct.productId, this.newProduct.productName, this.newProduct.productDescription, this.newProduct.productPrice);
    this.productService.addProduct({"productId": this.newProduct.productId, "productName": this.newProduct.productName, "productDescription": this.newProduct.productDescription, "productPrice": this.newProduct.productPrice}).subscribe((product:any[]) => this.products = product);
    //alert("Data added successfully....");    
    // $("#addProduct").hide();
    this.clear(form);
    this.addBtn.nativeElement.click();
    //$("#addProduct").modal("hide");
  }

  handleEditProduct(productId):void{
     for(let product of this.products){
       if(product.productId === productId){
         this.updateProduct.productId = product.productId;
         this.updateProduct.productName = product.productName;
         this.updateProduct.productDescription = product.productDescription;
         this.updateProduct.productPrice = product.productPrice;
       }
     }
  }

  editProduct(form:NgForm){
    console.log("In component: ", this.updateProduct.productId, this.updateProduct.productName, this.updateProduct.productDescription, this.updateProduct.productPrice);
    this.productService.editProduct({"productId": this.updateProduct.productId, "productName": this.updateProduct.productName, "productDescription": this.updateProduct.productDescription, "productPrice": this.updateProduct.productPrice}).subscribe((product:any[]) => this.products = product);
    this.clear(form);
    this.editBtn.nativeElement.click();
    //$("#updateProduct").modal("hide");
}

  deleteProduct(productID):void{
    console.log("In component: ", productID);
    this.productService.deleteProduct({"productId":productID}).subscribe((product:any[]) => this.products = product);
  }

  handleDeleteAll(){
    if(confirm("Are you sure?"))
      this.productService.deleteAllProduct().subscribe((product:any[]) => this.products = product);
  }

  clear(form:NgForm){
    form.resetForm();
  }
  
}
