import { Component, OnInit } from '@angular/core';
import { Product} from '../product';
import { ProductService} from '../product.service';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: Product[] = [];
  
  newProduct: Product = new Product();
  updateProduct: Product = new Product();
  p = 1;
  constructor(private productService: ProductService){}

  ngOnInit(){
    this.getProducts();
  }

  getProducts(){
    this.productService.getProducts().subscribe(product=> this.products = product);
  }

  addProduct(form:NgForm):void{
    console.log("In component: ", this.newProduct.productId, this.newProduct.productName, this.newProduct.productDescription, this.newProduct.productPrice);
    this.productService.addProduct({"productId": this.newProduct.productId, "productName": this.newProduct.productName, "productDescription": this.newProduct.productDescription, "productPrice": this.newProduct.productPrice}).subscribe((product:any[]) => this.products = product);
    alert("Data added successfully....");
    form.resetForm();
  }

  handleEditProduct(productId):void{
     for(let product of this.products){
       if(product.productId === productId){
         this.updateProduct.productId = product.productId;
         this.updateProduct.productName = product.productName;
         this.updateProduct.productDescription = product.productDescription;
         this.updateProduct.productPrice = product.productPrice;
       }
     }
  }

  editProduct(form:NgForm){
    console.log("In component: ", this.updateProduct.productId, this.updateProduct.productName, this.updateProduct.productDescription, this.updateProduct.productPrice);
    this.productService.editProduct({"productId": this.updateProduct.productId, "productName": this.updateProduct.productName, "productDescription": this.updateProduct.productDescription, "productPrice": this.updateProduct.productPrice}).subscribe((product:any[]) => this.products = product);
    form.resetForm();
}

  deleteProduct(productID):void{
    console.log("In component: ", productID);
    this.productService.deleteProduct({"productId":productID}).subscribe((product:any[]) => this.products = product);
  }

  
}
