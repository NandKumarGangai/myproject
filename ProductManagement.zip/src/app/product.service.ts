import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Product} from './product';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ProductService implements OnInit {

  private _urlGetProducts = "http://localhost:3000/products/display"; //read
  private _urlPostProduct = "http://localhost:3000/products/create"; //create
  private _urlPutProduct = "http://localhost:3000/products/update"; //update
  private _urlDeleteProduct = "http://localhost:3000/products/delete"; //delete
  private _urlPDeleteProduct = "http://localhost:3000/products/pdelete"; //delete
  constructor(private http: HttpClient) { }

  ngOnInit(){
    this.getProducts();
  }

  getProducts(): Observable<Product[]>{
      return this.http.get<Product[]>(this._urlGetProducts);
  }

  deleteProduct(product){
    console.log("In service: ", product);
    //return this.http.delete(this._urlDeleteProduct, product);
    return this.http.post(this._urlPDeleteProduct, product);
  }

  addProduct(product){
    console.log("In service: ", product);
    return this.http.post(this._urlPostProduct, product);
  }

  editProduct(product){
    console.log("In service: ", product);
    return this.http.post(this._urlPutProduct, product);
  }
}
