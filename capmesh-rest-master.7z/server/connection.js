const express = require('express')
const app = express()

const Dao = require('./modules/data-access/data-access')
const dao = new Dao()


class Connections {

    async getData(collections, name) {
        let result = await dao.find(collections, { userName: name });
        return (result);
    }

    async getNameAndImage(collections, name) {
        let result = await dao.aggregate(collections, [{ $match: { userName: name } }, { $project: { name: "$name", _id:"$userName", profile:"$profile.image" } }]);
        return (result);
    }


    /**
     * Getting count of followers
     */
    async getFollowersCount(collections, queryData) {
        let result = await dao.aggregate(collections, [{ $match: { userName: queryData.name } }, { $group: { _id: "$userName", count: { $sum: { $size: "$followers" } } } }]);
        return (result);
    }


    /**
     * Getting count of followings
     */
    async getFollowingsCount(collections, queryData) {
        let result = await dao.aggregate(collections, [{ $match: { userName: queryData.name } }, { $group: { _id: "$userName", count: { $sum: { $size: "$followings" } } } }]);
        return (result);
    }

    /**
     * Sending Follow request
     * (sender - receiver)
     */
    async follow(collections, queryData) {
        console.log(queryData);
        let result = await dao.update(collections, { userName: queryData.sender }, { $push: { "connectionRequests.sent": queryData.receiver } });
        let res = await dao.update(collections, { userName: queryData.receiver }, { $push: { "connectionRequests.receive": queryData.sender } });
        return (result);
    }

    /**
     * Accepting follow request
     * (user - requester)
     */
    async acceptInvitation(collections, queryData) {
        console.log(queryData);
        let result = await dao.update(collections, { userName: queryData.user }, { $pull: { "connectionRequests.receive": queryData.requester } });
        let res = await dao.update(collections, { userName: queryData.user }, { $push: { "followers": queryData.requester } });
        res = await dao.update(collections, { userName: queryData.requester }, { $pull: { "connectionRequests.sent": queryData.user } });
        res = await dao.update(collections, { userName: queryData.requester }, { $push: { "followings": queryData.user } });
        return (result);
    }

    /**
     * Unfollowing connection
     * (user - following)
     */
    async unfollowConnection(collections, queryData) {
        console.log(queryData);
        let result = await dao.update(collections, { userName: queryData.user }, { $pull: { "followings": queryData.following } });
        let res = await dao.update(collections, { userName: queryData.following }, { $pull: { "followers": queryData.user } });

        return (result);
    }

    /**
     * Blocking connection
     * (user - blockee)
     */
    async blockConnection(collections, queryData) {
        console.log(queryData);
        let result = await dao.update(collections, { userName: queryData.user }, { $push: { "blocklist.blocked": queryData.blockee } });
        let res = await dao.update(collections, { userName: queryData.blockee }, { $push: { "blocklist.blockedBy": queryData.user } });

        return (result);
    }

    /**
    * Unblocking connection
    *(user-blockee)
    */
    async unblock(collections, queryData) {
        console.log(queryData);
        let result = await dao.update(collections, { userName: queryData.user }, { $pull: { "blocklist.blocked": queryData.blockee } });
        let res = await dao.update(collections, { userName: queryData.blockee }, { $pull: { "blocklist.blocked": queryData.user } });
    }


    /**
     * Ignoring Invitation Received
     * (user-sender)
     */
    async ignoreRequest(collections, queryData) {
        console.log(queryData);
        let result = await dao.update(collections, { userName: queryData.user }, { $pull: { "connectionRequests.receive": queryData.sender } });
        let res = await dao.update(collections, { userName: queryData.sender }, { $pull: { "connectionRequests.sent": queryData.user } });
    }


    /**
     * View Invitations Sent Count
     * (user)
     */
    async invitationsSentCount(collections, queryData) {
        let result = await dao.aggregate(collections, [{ $match: { userName: queryData.user } }, { $group: { _id: "$userName", count: { $sum: { $size: "$connectionRequests.sent" } } } }]);
        return result;
    }

    /**
     * View Invitations Received Count
     */
    async invitationsReceivedCount(collections, queryData) {
        let result = await dao.aggregate(collections, [{ $match: { userName: queryData.user } }, { $group: { _id: "$userName", count: { $sum: { $size: "$connectionRequests.receive" } } } }]);
        return result;
    }

    /**
     * View Invitations Sent
     */
    async invitationsSent(collections, queryData) {
        let result = await dao.aggregate(collections, [{ $match: { userName: queryData.user } }, { $project: { sent: "$connectionRequests.sent" } }]);
        return (result);
    }

    /**
     * View Invitations Received
     */
    async invitationsReceived(collections, queryData) {
        let result = await dao.aggregate(collections, [{ $match: { userName: queryData.user } }, { $project: { receive: "$connectionRequests.receive" } }]);
        return (result);
    }

    


}

module.exports = Connections;