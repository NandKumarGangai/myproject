const express = require('express')
const app = express()
//const Connection = require('./connection');
const Connection = require('./connectionMod');
const Dao = require('./modules/data-access/data-access')
const connection = new Connection();
const dao = new Dao()
var parser = require("body-parser");
app.use(parser.json());
const connCollection = "userCollection";






app.post('/get-all-data', async (req, res) => {
    //let name = "Nandkumar";
    let result = await connection.getData(connCollection, req.body.name);
    res.end(result)
})


/**
* Getting count of followers
*/
app.post('/get-count/followers', async (req, res) => {

    let result = await connection.getConnectionCount(connCollection, req.body);
    res.end(result)
})

/**
* Getting count of followers
*/
app.post('/get-count/followings', async (req, res) => {

    let result = await connection.getConnectionCount(connCollection, req.body);
    res.end(result)
})

/**
 * Sending Follow request
 * (sender - receiver)
 */
app.post('/connect', async (req, res) => {

    let result1 = await connection.connect(connCollection, req.body);
    res.end("Request Sent");
})


/**
 * Accepting follow request
 * (user - requester)
 */
app.post('/accept-invitation', async (req, res) => {

    let result = await connection.acceptInvitation(connCollection, req.body);
    res.end("Request Accepted");
})


// /**
//  * Unfollowing connection
//  * (user - following)
//  */
// app.post('/unfollow', async (req, res) => {

//     let result = await connection.unfollowConnection(connCollection, req.body);
//     res.end("Unfollowed");
// })


/**
 * removing connection
 * (user - connection)
 */
app.post('/remove-connection', async (req, res) => {

    let result = await connection.removeConnection(connCollection, req.body);
    res.end("Removed");
})


/**
 * Blocking connection
 * (user - blockee)
 */
app.post('/block', async (req, res) => {

    let result = await connection.blockConnection(connCollection, req.body);
    res.end("Blocked");
})


/**
* Unblocking connection
*(user-blockee)
*/
app.post('/unblock', async (req, res) => {

    let result1 = await connection.unblock(connCollection, req.body);
    res.end("Unblocked");
})


/**
 * Ignoring Invitation Received
 * (user-sender)
 */
app.post('/ignore-invitation', async (req, res) => {

    let result1 = await connection.ignoreRequest(connCollection, req.body);
    res.end("Request Ignored");
})


/**
 * View Invitations Sent Count
 * (user)
 */
app.post('/get-invitation-count/sent', async (req, res) => {
    let result = await connection.invitationsSentCount(connCollection, req.body);
    res.end(JSON.stringify(result));
})


/**
 * View Invitations Received Count
 */
app.post('/get-invitation-count/received', async (req, res) => {
    let result = await connection.invitationsReceivedCount(connCollection, req.body);
    res.end(JSON.stringify(result));
})


/**
* View Invitations Sent
*/
app.post('/get-invitations/sent', async (req, res) => {
    let result = await connection.invitationsSent(connCollection, req.body);
    var sentData = [];
    console.log(result[0].sent.length);
    for (let s of result[0].sent) {

        sentData.push(await connection.getNameAndImage(connCollection, s))
    }
    res.end(JSON.stringify(sentData));
})

/**
* View Invitations Received
*/
app.post('/get-invitations/received', async (req, res) => {
    let result = await connection.invitationsReceived(connCollection, req.body);
    var receivedData = [];
   console.log(result[0].receive.length);
    for (let s of result[0].receive) {

        receivedData.push(await connection.getNameAndImage(connCollection, s))
    }
    res.end(JSON.stringify(receivedData));
})












app.post('/rest/api/users/add', async (req, res) => {
    obj = {
        userName: 'soumya145',
        name: 'soumya',
        email: 'soumyaN@hotmail.com',
        mobile: '9123876903',
        gender: 'F', dateOfBirth:
        new Date("1996-07-01"),
        isVerified: false,
        isDeleted: false
    }
    let result
    try {
        result = await dao.insert("users");
    }
    catch (e) {
        result = { error: "err" };
    }
    res.send(result)
})

app.delete('/rest/api/users/delete/', async (req, res) => {
    let result = await dao.delete("users", { name: 'soumya' })
    res.send(result)
})

app.patch('/rest/api/users/update/', async (req, res) => {
    let result
    try {
        result = await dao.update("users", { name: 'soumya' }, { $set: { name: "Soumya" } })
    }
    catch (err) {
        result = { err: err }
    }
    res.send(result)
})


app.listen('8080', () => console.log('Listening on port 8080'));