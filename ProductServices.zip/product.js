var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');

exp.use(cors());
exp.use(parser.json());

/**
 * Create
 */
exp.route('/products/create', cors()).post((req, res)=>{
    console.log('Create Invoked....', (req.body));
    var productsList;
    fs.readFile('products.json', function(err, data) {
        if(err) throw err;        
        productsList = JSON.parse(data.toLocaleString());
        var products = productsList;
        products.push(req.body);
        productsList = products;

        fs.writeFileSync("products.json", JSON.stringify(productsList));
        res.send(productsList);
        res.end();
    });
});

/**
 * Read
 */
exp.route('/products/display', cors()).get((req, res)=>{
    console.log('Get Invoked....');
    var productsList;
    fs.readFile('products.json', function(err, data) {
        if(err) throw err;
        //res.writeHead(200, {'Content-Type': 'text/plain'});
        productsList = JSON.parse(data);
        //console.log(productsList);
        res.send(productsList);
        res.end();
    });
});

/**
 * Update
 */
exp.route('/products/update', cors()).post((req, res)=>{
    console.log('Update Invoked....', (req.body).productId);
    var productId= (req.body).productId;
    var productName = (req.body).productName;
    var productDescription = (req.body).productDescription;
    var productPrice = (req.body).productPrice;
    var productsList;
    fs.readFile('products.json', function(err, data) {
        if(err) throw err;
        
        productsList = JSON.parse(data.toLocaleString());
        for(let p of productsList){
            if(p.productId === productId){
                if(productName !== undefined)
                    p.productName = productName;
                if(productDescription !== undefined)
                    p.productDescription = productDescription;
                if(productPrice !== undefined)
                    p.productPrice = productPrice;
                console.log(p);
            }
        }
        fs.writeFileSync("products.json", JSON.stringify(productsList));
        //console.log(productsList);
        res.send(productsList);
        res.end("DONE");
        
    });
});

/**
 * Delete
 */
exp.route('/products/delete', cors()).delete((req, res)=>{
    console.log('Delete Invoked....', (req.body).productId);
    var productsList;
    fs.readFile('products.json', function(err, data) {
        if(err) throw err;        
        productsList = JSON.parse(data.toLocaleString());
        let products = productsList;
        for(let i=0; i<products.length; i++){
            if(products[i].productId === (req.body).productId){
                products.splice(i, 1);
            }
        }
        productsList = products;
        fs.writeFileSync("products.json", JSON.stringify(productsList));
        res.send(productsList);
        res.end();
    });
});

/** 
 * Delete using post
 */
exp.route('/products/pdelete', cors()).post((req, res)=>{
    console.log('Delete Invoked....', (req.body).productId);
    var productsList;
    fs.readFile('products.json', function(err, data) {
        if(err) throw err;        
        productsList = JSON.parse(data.toLocaleString());
        let products = productsList;
        for(let i=0; i<products.length; i++){
            if(products[i].productId === (req.body).productId){
                products.splice(i, 1);
            }
        }
        productsList = products;
        fs.writeFileSync("products.json", JSON.stringify(productsList));
        res.send(productsList);
        res.end();
    });
});




exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));